package CGI::Fast;

# See the bottom of this file for the POD documentation.  Search
# for the string '=head'.

# You can run this file through either pod2man or pod2html to produce
# pretty documentation in manual or html file format (these utilities
# are part of the Perl 5 distribution).

# Copyright 2001, Rob Saccoccio.  All rights reserved.
# Copyright 1995,1996, Lincoln D. Stein.  All rights reserved.
#
# It may be used and modified freely, but I do request that this 
# copyright notice remain attached to the file.  You may modify this 
# module as you wish, but if you redistribute a modified version, 
# please attach a note listing the modifications you have made.

# The most recent version and complete docs are available at:
#   http://stein.cshl.org/WWW/software/CGI/

use strict;
use warnings;

$CGI::Fast::VERSION = '2.02';

$CGI::Fast::NO_ACCEPT_FLAG = 'NO_ACCEPT';

use FCGI ();

use vars qw($DEFAULT_FCGI);
sub BEGIN 
{
    # these have to be setup before the 'use CGI'
    @CGI::Fast::ISA = ('CGI');
    $CGI::DefaultClass = 'CGI::Fast';
    $CGI::Fast::AutoloadClass = 'CGI';

    if ($ENV{FCGI_SOCKET_PATH}) 
    {
        # XXX This code really belongs in FCGI.pm.
        # It was an undocumented feature of CGI release 2.76 and therefore is 
        # required for backward compatibility - leave it undocumented.
        my $path    = $ENV{FCGI_SOCKET_PATH};
        my $backlog = $ENV{FCGI_LISTEN_QUEUE} || 100;
        my $socket  = FCGI::OpenSocket($path, $backlog);
        $DEFAULT_FCGI = FCGI::Request(\*STDIN, \*STDOUT, \*STDERR, 
                                      \%ENV, $socket, 
                                      $FCGI::FAIL_ACCEPT_ON_INTR);
    }
    else
    {
        # Early versions of FCGI don't have $global_request
        $DEFAULT_FCGI = defined $FCGI::global_request
            ? $FCGI::global_request
            : FCGI::Request();
    }

    # The FCGI object used with non-FCGI initializers
    $CGI::Fast::STD_FCGI = FCGI::Request();
}

sub AUTOLOAD 
{
    my ($package, $function) = $CGI::Fast::AUTOLOAD =~ /(.+)::([^:]+)$/;

    no strict 'refs';

    $package = 'CGI::Fast' unless (${"$package\:\:AutoloadClass"} 
        || defined(${"$package\:\:AUTOLOADED_ROUTINES"}));

    $CGI::AUTOLOAD = "$package\:\:$function";

    goto &CGI::AUTOLOAD;
}

# BEGIN and AUTOLOAD have to be compiled before CGI
use CGI 2.7802 ();

# Override - don't read AUTH requests  
sub read_from_client 
{
    my $self = shift;

    return 0 if $self->is_authorizer_request();

    $_[0] = ($self->{'FCGI'}->GetHandles())[0];

    $self->SUPER::read_from_client(@_);
}

# Override - don't read AUTH requests 
sub read_multipart 
{
    my $self = shift;

    return 0 if $self->is_authorizer_request();

    # read_from_client() will be called and the STDIN handle fixed there
    $self->SUPER::read_multipart(@_);
}

sub is_authorizer_request()
{
    my ($self) = @_;
    return defined $self->env()->{'FCGI_ROLE'} 
           && $self->env()->{'FCGI_ROLE'} =~ /AUTH/i;
}

# Override
sub print 
{
    my $self = shift;
    print { ($self->{'FCGI'}->GetHandles())[1] } @_;
}

# Override - don't save state to CGI package global variables 
sub save_request 
{
    # no-op
}

# If $initializer is undef use the DEFAULT_FCGI object.
sub new 
{
    my ($class, $initializer, @flags) = @_;

    $initializer = $DEFAULT_FCGI if not defined $initializer;

    my $self = $class->SUPER::new($initializer, @flags);
    return defined $self->{'FCGI'} ? $self : undef;
}

# Override (called by the CGI contructor).
sub init
{
    my ($self, $initializer, @flags) = @_;

    if (UNIVERSAL::isa($initializer, 'FCGI'))
    {
        if (! grep { defined $_ && /^$CGI::Fast::NO_ACCEPT_FLAG$/ } @flags)
        {
            return if ($initializer->Accept() < 0);
        }

        $self->{'FCGI'} = $initializer;

    	# Hide the $initializer so CGI does "normal" handling
    	$initializer = undef;
    }
    else
    {
        $self->{'FCGI'} = $CGI::Fast::STD_FCGI;
    }
    
    # Make the default CGI object $self
    $CGI::Q = $self;

    $self->SUPER::init($initializer);
}

# Override
sub env 
{
    my ($self) = @_;
    return $self->{'FCGI'}->GetEnvironment();
}

# Override - always clear the namespace
sub import_names 
{
    my($self, $namespace) = self_or_default(@_);

    die "Can't import names into \"main\"\n" if \%{"${namespace}::"} == \%::;

    $self->_clear_namespace($namespace);
    $self->_import_parameters($namespace);
}

1;

=head1 NAME

CGI::Fast - CGI Interface for FastCGI

=head1 SYNOPSIS

    use CGI::Fast;

    initialize();

    while (new CGI::Fast) {
		process_request();
    }

=head1 DESCRIPTION

CGI::Fast is a specialized CGI object designed for use with the FastCGI
standard.  FastCGI greatly speeds up CGI scripts by turning them into
persistent server processes.  Scripts that perform time-consuming
initialization processes, such as loading large modules or opening
persistent database connections, will see large performance
improvements.

=head1 OTHER PIECES OF THE PUZZLE

In order to use CGI::Fast you need a FastCGI-enabled Web server (or a 
CGI-FastCGI bridge) and the FCGI module.

You can find a list of Web servers known to support FastCGI, a CGI-FastCGI
bridge, and other FastCGI goodies at:

    http://fastcgi.com/
                                      
The FCGI module is available on CPAN 
(http://www.cpan.org/modules/by-module/FCGI/).

=head1 WRITING FASTCGI SCRIPTS

FastCGI scripts are persistent: one or more copies are started and
remain running in order to handle requests.  How and when scripts are
started is Web server and configuration dependent.  Some web servers
provide a means to start scripts at server initialization and/or based
on client demand.  Others require the script to be started
independently.

After performing whatever one-time initialization it needs, the script
enters a loop waiting for an incoming request, processes the request,
and waits again for the next request.

A typical FastCGI script using CGI.pm's function oriented style (and
the default CGI object) looks like this:

    use CGI::Fast qw(:standard);

    my $COUNTER = 0;

    while (new CGI::Fast) {
		print 
		    header(),
	            start_html("Fast CGI Rocks"),
		    h1("Fast CGI Rocks"),
		    "PID ", b($$), br(),
		    "Invocation count ", b($COUNTER++),
		    hr(),
		    end_html();
    }

When the server requests that your script be terminated, new() will
return undef.  You can of course exit earlier if you choose.  

CGI.pm's object oriented style is also supported.  Using this 
approach will make porting to a threaded application easier (once
fully supported).

    use CGI::Fast ();

    my $COUNTER = 0;

    while (my $q = new CGI::Fast) {
		process_request($q);
    }

    sub process_request($) {
	    my $q = shift;

	    $q->print 
	        $q->header(),
            $q->start_html("Fast CGI Rocks"),
	        $q->h1("Fast CGI Rocks"),
	        "PID ", $q->b($$), $q->br(),
	        "Invocation count ", $q->b($COUNTER++),
	        $q->hr(),
	        $q->end_html();
    }

=head1 INDEPENDENT INITIALIZATION

A FastCGI script can be started without the assistance of a server by
creating its own listen socket and using it in the FCGI object used by
the script.  The default FCGI object is $CGI::Fast::DEFAULT_FCGI, it 
is used when no FCGI object is passed to the CGI::Fast constructor.

    # Listen on TCP port 8888 with a backlog of 100
    my $socket = FCGI::OpenSocket(":8888", 100);
    my $fcgi = FCGI::Request(\*STDIN, \*STDOUT, \*STDERR, \%ENV, $socket);

    
    $CGI::Fast::DEFAULT_FCGI = $fcgi;

        or

    while (new CGI::Fast($fcgi)) { ... }

See L<FCGI> for more information.

=head1 THREADED SCRIPTS

As of this writing, threads in Perl are still considered experimental
- this is too.  Perl thread support must be explicitly configured when
building Perl.

A simple threaded application looks like this:

    use CGI::Fast ();
    use Thread;
    use IO::Handle;

    use constant THREAD_COUNT => 5;

    sub doit {
        my $k = shift;

        my %env;
        my $in = new IO::Handle;
        my $out = new IO::Handle;
        my $err = new IO::Handle;

        my $request = FCGI::Request($in, $out, $err, \%env);

        while (my $q = CGI::Fast($request)) {
    	    process_request($q);
        }
    }

    for (my $t = 1; $t < THREAD_COUNT; ++$t) {
        new Thread \&doit, $t;
    }

    doit(0);

=head1 SPECIAL CONSIDERATIONS

Because FastCGI scripts are persistent, memory leaks can be problematic.
If leaks can't be resolved and the script was started by a server (or
other caring parent) that restarts failed scripts, exiting periodically
may suffice to ward off the effects of the leak.

=head1 FASTCGI AUTHORIZERS

POST data cannot be read by an authorizer (its intended for the 
responder).  See the FastCGI specification for more information.

=head1 USING FASTCGI SCRIPTS AS CGI SCRIPTS

Any script that works correctly as a FastCGI script will also work
correctly when installed as a vanilla CGI script.  However it will
not see any performance benefit.

=head1 AUTHOR INFORMATION

Copyright 2001, Rob Saccoccio.  All rights reserved.  
Copyright 1996-1998, Lincoln D. Stein.  All rights reserved.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

Address bug reports and comments to: lstein@cshl.org, robs@fastcgi.com

=head1 BUGS

Use with other CGI modules (e.g. CGI::Carp, CGI::Pretty) hasn't been tested.

=head1 SEE ALSO

L<FCGI>, L<CGI>

=cut
